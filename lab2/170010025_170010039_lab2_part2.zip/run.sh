cp -f forkexit.c /usr/src/minix/servers/pm/forkexit.c
make build MKUPDATE=yes >log.txt 2>log.txt